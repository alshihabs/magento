<?php

namespace GiftMagic\GetGiftMagic\Block;

use Magento\Framework\View\Element\Template;
use GiftMagic\GetGiftMagic\Helper\Config;
use Magento\Customer\Model\Session;

class Checkout extends Template
{
    /** @var Config */
    private $config;
    /** @var Session */
    private $session;

    public function __construct(
        Template\Context $context,
        Config $config,
        Session $session,
        array $data = []
    )
    {
        $this->config = $config;
        $this->session = $session;
        parent::__construct($context, $data);
    }

    public function isEnabled(): bool
    {
        return $this->config->isActive();
    }

    public function isGift()
    {
        if ($this->session->getIsGift()) {
            $this->session->setIsGift(false);
            return true;
        }

        return false;
    }

    public function getEmail()
    {
        if ($email = $this->session->getGiftSenderEmail()) {
            return $email;
        }

        return '';
    }
}
