<?php

namespace GiftMagic\GetGiftMagic\Block\Adminhtml\Sales\Order;

use Magento\Sales\Block\Adminhtml\Order\AbstractOrder;
use Magento\Framework\View\Element\Template;

class Gift extends AbstractOrder
{
    public function isGift() {
        $order = $this->getOrder();
        if ($order->getGiftId()) {
            return true;
        }

        return false;
    }
}
