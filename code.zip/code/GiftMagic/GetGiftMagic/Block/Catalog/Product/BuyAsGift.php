<?php

namespace GiftMagic\GetGiftMagic\Block\Catalog\Product;

use Magento\Framework\View\Element\Template;
use GiftMagic\GetGiftMagic\Helper\Config;

class BuyAsGift extends Template
{
    /** @var Config */
    private $config;

    public function __construct(
        Template\Context $context,
        Config $config,
        array $data = []
    )
    {
        $this->config = $config;
        parent::__construct($context, $data);
    }

    public function isEnabled(): bool
    {
        return $this->config->isActive();
    }
}
