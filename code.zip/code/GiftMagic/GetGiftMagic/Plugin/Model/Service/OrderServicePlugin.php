<?php

namespace GiftMagic\GetGiftMagic\Plugin\Model\Service;

use Magento\Sales\Model\Order;
use Magento\Sales\Model\Service\OrderService;
use GiftMagic\GetGiftMagic\Helper\Config;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use GuzzleHttp\Client;
use Magento\Customer\Model\Session;
use GiftMagic\GetGiftMagic\Logger\GetGiftMagicLogger;

class OrderServicePlugin
{
    const URL = "https://api.swiftgift.me/v1/giftmagic/fulfill";

    /** @var Config */
    private $config;
    /** @var CartRepositoryInterface */
    private $cartRepository;
    /** @var OrderRepositoryInterface */
    private $orderRepository;
    /** @var Client */
    private $client;
    /** @var Session */
    private $session;
    /** @var GetGiftMagicLogger */
    private $getGiftMagicLogger;

    public function __construct(
        Config $config,
        CartRepositoryInterface $cartRepository,
        OrderRepositoryInterface $orderRepository,
        Client $client,
        Session $session,
        GetGiftMagicLogger $getGiftMagicLogger
    )
    {
        $this->config = $config;
        $this->cartRepository = $cartRepository;
        $this->orderRepository = $orderRepository;
        $this->client = $client;
        $this->session = $session;
        $this->getGiftMagicLogger = $getGiftMagicLogger;
    }

    /**
     * @param OrderService $subject
     * @param Order $order
     * @return Order
     * @throws GuzzleException
     */
    // @codingStandardsIgnoreStart
    public function afterPlace(OrderService $subject, Order $order)
    // @codingStandardsIgnoreEnd
    {
        if ($this->config->isActive()) {
            $quote = $this->cartRepository->get($order->getQuoteId());
            if ($giftId = $quote->getGiftId()) {
                try {
                    $data = [
                        'giftmagic_order_id' => $this->session->getData('giftmagic_order_id'),
                        'internal_order_id' => $order->getIncrementId()
                    ];
                    $response = $this->client->post(self::URL, [
                        'json' => $data
                    ]);
                } catch (\Exception $e) {
                    $this->getGiftMagicLogger->error($e->getMessage());
                }
                $order->setGiftId($giftId);
                $this->orderRepository->save($order);
            }
        }

        return $order;
    }
}
