define([
    'ko',
    'jquery',
    'underscore',
    'uiComponent',
    'Magento_Ui/js/modal/confirm',
    'Magento_Customer/js/customer-data',
    'mage/url',
    'mage/template',
    'mage/translate'
], function (ko, $, _, Component, confirm, customerData, urlBuilder, mageTemplate, $t) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'GiftMagic_GetGiftMagic/shop_as_gift',
            buttonText: $t('Shop as Gift'),
            proceedUrl: urlBuilder.build('swiftgift/index/proceed'),
            showButton: false,
            productFormSelector: '#product_addtocart_form',
        },

        /** @inheritdoc */
        initialize: function () {
            this._super();
        },

        buyAsGift: function () {
            var form = $(this.productFormSelector);
            var isValid = form.validation('isValid');
            if (isValid) {
                var self = this;
                $.ajax({
                    url: this.proceedUrl,
                    data: form.serialize(),
                    type: 'post',
                    dataType: 'json',
                    beforeSend: function () {
                        $('body').trigger('processStart');
                    },
                    success: function(response) {
                        self.redirect(response.url);
                    }
                }).always(function () {
                    $('body').trigger('processStop');
                });
            }
        },

        redirect: function (url) {
            window.location.replace(url);
        }
    });
});
