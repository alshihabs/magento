<?php

namespace GiftMagic\GetGiftMagic\Logger;

use \Monolog\Logger;

class GetGiftMagicLogger extends Logger
{
}
