<?php

namespace GiftMagic\GetGiftMagic\Logger\Handler;

use Magento\Framework\Logger\Handler\Base;
use Monolog\Logger;

class GetGiftMagic extends Base
{
    protected $fileName = '/var/log/get_gift_magic.log';
    protected $loggerType = Logger::DEBUG;
}
