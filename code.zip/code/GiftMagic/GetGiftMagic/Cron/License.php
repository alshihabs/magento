<?php

namespace GiftMagic\GetGiftMagic\Cron;

use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Cache\TypeListInterface;
use GuzzleHttp\Client;
use Magento\Store\Model\StoreManagerInterface;
use \Magento\Framework\UrlInterface;
use GiftMagic\GetGiftMagic\Logger\GetGiftMagicLogger;

class License
{
    const URL = 'https://api.swiftgift.me/v1/companies/public/%s';

    /** @var WriterInterface */
    private $configWriter;
    /** @var TypeListInterface */
    private $typeList;
    /** @var Client */
    private $client;
    /** @var StoreManagerInterface */
    private $storeManager;
    /** @var GetGiftMagicLogger */
    private $getGiftMagicLogger;

    public function __construct(
        WriterInterface $configWriter,
        TypeListInterface $typeList,
        Client $client,
        StoreManagerInterface $storeManager,
        GetGiftMagicLogger $getGiftMagicLogger
    )
    {
        $this->configWriter = $configWriter;
        $this->typeList = $typeList;
        $this->client = $client;
        $this->storeManager = $storeManager;
        $this->getGiftMagicLogger = $getGiftMagicLogger;
    }

    public function execute()
    {
        $active = 0;
        $url = sprintf(
            self::URL,
            preg_replace("#^[^:/.]*[:/]+#i", "", $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_WEB))
        );
        try {
            $response = $this->client->get($url);
            $content = json_decode($response->getBody()->__toString(), true);
            if (array_key_exists('status', $content) && $content['status'] === 'active') {
                $active = 1;
            }
        } catch (\Exception $e) {
            $this->getGiftMagicLogger->error($e->getMessage());
        }
        $this->configWriter->save('giftmagic/license/active', $active, $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT, $scopeId = 0);
        $this->typeList->cleanType('config');
    }
}
