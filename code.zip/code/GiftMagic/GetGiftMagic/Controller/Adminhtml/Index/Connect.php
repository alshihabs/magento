<?php

namespace GiftMagic\GetGiftMagic\Controller\Adminhtml\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Cache\TypeListInterface;
use GuzzleHttp\Client;
use GiftMagic\GetGiftMagic\Helper\Config;
use Magento\Integration\Api\IntegrationServiceInterface;
use Magento\Store\Model\StoreManagerInterface;

class Connect extends Action
{
    const URL = "https://api.swiftgift.me/v1/giftmagic/magento/authTokens";

    /** @var WriterInterface */
    private $configWriter;
    /** @var TypeListInterface */
    private $typeList;
    /** @var Client */
    private $client;
    /** @var Config */
    private $config;
    /** @var IntegrationServiceInterface */
    private $integrationService;
    /** @var StoreManagerInterface */
    private $storeManager;

    public function __construct(
        Context $context,
        WriterInterface $configWriter,
        TypeListInterface $typeList,
        Client $client,
        Config $config,
        IntegrationServiceInterface $integrationService,
        StoreManagerInterface $storeManager
    )
    {
        $this->configWriter = $configWriter;
        $this->typeList = $typeList;
        $this->client = $client;
        $this->config = $config;
        $this->integrationService = $integrationService;
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }

    public function execute()
    {
        $integrationId = $this->config->getIntegrationId();
        if ($integrationId) {
            $integration = $this->integrationService->get($integrationId);
            $data = [
                'consumer_key' => $integration->getConsumerKey(),
                'consumer_secret' => $integration->getConsumerSecret(),
                'access_token' => $integration->getToken(),
                'access_secret' => $integration->getTokenSecret(),
                'api_url' => sprintf(
                    "%s%s",
                    $this->storeManager->getStore()->getBaseUrL(),
                    'rest/'
                )
            ];
            $response = $this->client->post(self::URL, [
                'json' => $data,
                'verify' => false
            ]);
            $body = json_decode($response->getBody()->__toString(), true);
            if (array_key_exists('landing_url', $body)) {
                $this->configWriter->save(Config::GIFTMAGIC_DEFAULT_URL, $body['landing_url'], $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT);
                $this->typeList->cleanType('config');
            } else {
                throw new \Exception('No landing page url returned.');
            }
        } else {
            Throw new \Exception('Integration not present.');
        }
    }
}
