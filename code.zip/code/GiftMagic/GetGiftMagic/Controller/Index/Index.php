<?php

namespace GiftMagic\GetGiftMagic\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Customer\Model\Session;
use GiftMagic\GetGiftMagic\Api\SwiftGiftRepositoryInterface;
use Magento\Quote\Model\QuoteRepository;
use Magento\Framework\Data\Form\FormKey;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Api\ProductRepositoryInterface;
use GiftMagic\GetGiftMagic\Model\ResourceModel\Country;
use GiftMagic\GetGiftMagic\Logger\GetGiftMagicLogger;

class Index extends Action
{
    /** @var ResultFactory */
    private $resultRedirect;
    /** @var Session */
    private $session;
    /** @var SwiftGiftRepositoryInterface */
    private $swiftGiftRepository;
    /** @var QuoteRepository */
    private $quoteRepository;
    /** @var Cart */
    private $cart;
    /** @var FormKey */
    private $formKey;
    /** @var ProductRepositoryInterface */
    private $productRepository;
    /** @var Country */
    private $country;
    /** @var GetGiftMagicLogger */
    private $getGiftMagicLogger;

    public function __construct(
        Context $context,
        ResultFactory $resultRedirect,
        Session $session,
        SwiftGiftRepositoryInterface $swiftGiftRepository,
        QuoteRepository $quoteRepository,
        Cart $cart,
        FormKey $formKey,
        ProductRepositoryInterface $productRepository,
        Country $country,
        GetGiftMagicLogger $getGiftMagicLogger
    )
    {
        $this->resultRedirect = $resultRedirect;
        $this->session = $session;
        $this->swiftGiftRepository = $swiftGiftRepository;
        $this->quoteRepository = $quoteRepository;
        $this->cart = $cart;
        $this->formKey = $formKey;
        $this->productRepository = $productRepository;
        $this->country = $country;
        $this->getGiftMagicLogger = $getGiftMagicLogger;
        parent::__construct($context);
    }

    public function execute()
    {
        try {
            $resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
            $params = $this->getRequest()->getParams();
            if (!empty($params) &&
                !empty($recipient = $params['recipient']) &&
                !empty($address = $params['delivery_address']) &&
                !empty($giftId = $params['gift_id'])) {
                $gift = $this->swiftGiftRepository->getById($giftId);
                $items = json_decode($gift->getItems(), true);
                if (!empty($items['goods'])) {
                    foreach ($this->cart->getItems() as $item) {
                        $this->cart->removeItem($item->getId());
                    }
                    foreach ($items['goods'] as $item) {
                        $product = $this->productRepository->get($item['sku']);
                        $addToCartParams = [
                            'form_key' => $this->formKey->getFormKey(),
                            'product' => $product->getId(),
                            'qty' => $item['quantity']
                        ];
                        if (!empty($item['super_attribute'])) {
                            $addToCartParams['super_attribute'] = $item['super_attribute'];
                        }

                        $this->cart->addProduct($product, $addToCartParams);
                    }
                    $senderEmail = $params['sender']['email'];
                    $shippingAddress = $this->cart->getQuote()->getShippingAddress();
                    $shippingAddress->setEmail($senderEmail);
                    $shippingAddress->setStreet([$address['street_address1'], $address['street_address2']]);
                    $shippingAddress->setCity($address['city']);
                    $shippingAddress->setCountryId($address['country']);
                    $shippingAddress->setFirstname($recipient['first_name']);
                    $shippingAddress->setLastname($recipient['last_name']);
                    $shippingAddress->setPostcode($address['postcode']);
                    $shippingAddress->setTelephone($recipient['phone']);
                    $this->cart->getQuote()->setShippingAddress($shippingAddress);
                    $this->cart->getQuote()->setGiftId($giftId);
                    $this->session->setIsGift(true);
                    $this->session->setGiftSenderEmail($senderEmail);
                    if ($giftOrderId = $this->getRequest()->getParam('giftmagic_order_id')) {
                        $this->session->setGiftmagicOrderId($giftOrderId);
                    }

                    $this->cart->save();
                    return $resultRedirect->setUrl('/checkout');
                }
            }
        } catch (\Exception $e) {
            $this->getGiftMagicLogger->error($e->getMessage());
        }

        $this->messageManager->addErrorMessage('Can\'t initialize checkout. Please contact administrator.');
        return $resultRedirect->setUrl('/');
    }
}
