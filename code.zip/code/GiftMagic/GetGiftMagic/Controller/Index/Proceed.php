<?php

namespace GiftMagic\GetGiftMagic\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Catalog\Api\ProductRepositoryInterface;
use GiftMagic\GetGiftMagic\Helper\Config;
use Magento\Framework\Controller\Result\JsonFactory;
use GiftMagic\GetGiftMagic\Api\SwiftGiftRepositoryInterface;
use GiftMagic\GetGiftMagic\Api\Data\SwiftGiftInterfaceFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;

class Proceed extends Action
{
    /** @var ProductRepositoryInterface */
    private $productRepository;
    /** @var Config */
    private $config;
    /** @var JsonFactory */
    private $jsonFactory;
    /** @var SwiftGiftInterfaceFactory */
    private $swiftGiftInterfaceFactory;
    /** @var SwiftGiftRepositoryInterface */
    private $swiftGiftRepository;
    /** @var StoreManagerInterface */
    private $storeManager;
    /** @var Configurable */
    private $configurable;

    public function __construct(
        Context $context,
        ProductRepositoryInterface $productRepository,
        Config $config,
        JsonFactory $jsonFactory,
        SwiftGiftInterfaceFactory $swiftGiftInterfaceFactory,
        SwiftGiftRepositoryInterface $swiftGiftRepository,
        StoreManagerInterface $storeManager,
        Configurable $configurable
    )
    {
        $this->productRepository = $productRepository;
        $this->config = $config;
        $this->jsonFactory = $jsonFactory;
        $this->swiftGiftInterfaceFactory = $swiftGiftInterfaceFactory;
        $this->swiftGiftRepository = $swiftGiftRepository;
        $this->storeManager = $storeManager;
        $this->configurable = $configurable;
        parent::__construct($context);
    }

    public function execute()
    {
        $request = $this->getRequest();
        $url = $this->config->getGiftUrl();
        if (($id = $request->getParam('product')) && ($qty = $request->getParam('qty'))) {
            $product = $this->productRepository->getById($id);
            $configurableSku = $attributes = false;
            if ($product->getTypeId() === 'configurable' && !empty($attributes = $request->getParam('super_attribute'))) {
                $configurableSku = $product->getSku();
                $product = $this->configurable->getProductByAttributes($attributes, $product);
            }

            $toSave = [
                'goods' => [
                    [
                        'sku' => ($configurableSku) ?: $product->getSku(),
                        'quantity' => $qty,
                        'super_attribute' => $attributes
                    ]
                ]
            ];
            $gift = $this->swiftGiftInterfaceFactory->create();
            $gift->setItems(json_encode($toSave));
            $this->swiftGiftRepository->save($gift);
            $params = http_build_query([
                'goods' => [
                    [
                        'id' => $product->getSku(),
                        'quantity' => $qty
                    ]
                ],
                'gift_id' => $gift->getId(),
                'store_code' => $this->storeManager->getStore()->getCode()
            ]);
            $url = sprintf(
                "%s?%s",
                $url,
                $params
            );
        } else {
            throw new \Exception('GiftMagicError: Product is empty.');
        }

        $resultJson = $this->jsonFactory->create();
        return $resultJson->setData(['url' => $url]);
    }
}
