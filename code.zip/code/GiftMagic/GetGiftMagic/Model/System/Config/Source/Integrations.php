<?php

namespace GiftMagic\GetGiftMagic\Model\System\Config\Source;

use Magento\Integration\Model\ResourceModel\Integration\Collection;
use Magento\Framework\Data\OptionSourceInterface;

class Integrations implements OptionSourceInterface
{
    /** @var Collection */
    private $collection;

    public function __construct(
        Collection $collection
    )
    {
        $this->collection = $collection;
    }

    public function toOptionArray()
    {
        $result = [];
        foreach ($this->collection->getItems() as $item) {
            $result[] = [
                'value' => $item->getId(),
                'label' => $item->getName()
            ];
        }

        return $result;
    }
}
