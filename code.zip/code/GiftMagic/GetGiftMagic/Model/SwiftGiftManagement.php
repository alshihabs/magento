<?php

namespace GiftMagic\GetGiftMagic\Model;

use GiftMagic\GetGiftMagic\Api\SwiftGiftManagementInterface;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Cache\TypeListInterface;

class SwiftGiftManagement implements SwiftGiftManagementInterface
{
    /** @var WriterInterface  */
    private $configWriter;
    /** @var TypeListInterface  */
    private $typeList;

    public function __construct(
        WriterInterface $configWriter,
        TypeListInterface $typeList
    )
    {
        $this->configWriter = $configWriter;
        $this->typeList = $typeList;
    }

    public function setUrl($url)
    {
        $this->configWriter->save('giftmagic/default/url', $url, $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT, $scopeId = 0);
        $this->typeList->cleanType('config');
    }
}
