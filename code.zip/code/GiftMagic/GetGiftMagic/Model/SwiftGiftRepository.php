<?php

namespace GiftMagic\GetGiftMagic\Model;

use GiftMagic\GetGiftMagic\Api\Data\SwiftGiftInterface;
use GiftMagic\GetGiftMagic\Api\SwiftGiftRepositoryInterface;
use GiftMagic\GetGiftMagic\Model\ResourceModel\SwiftGift as ResourceModel;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use GiftMagic\GetGiftMagic\Model\SwiftGiftFactory;
use Magento\Framework\Exception\CouldNotDeleteException;

class SwiftGiftRepository implements SwiftGiftRepositoryInterface
{
    /** @var ResourceModel */
    private $resourceModel;
    /** @var \GiftMagic\GetGiftMagic\Model\SwiftGiftFactory */
    private $swiftGiftFactory;

    public function __construct(
        ResourceModel $resourceModel,
        SwiftGiftFactory $swiftGiftFactory
    )
    {
        $this->resourceModel = $resourceModel;
        $this->swiftGiftFactory = $swiftGiftFactory;
    }

    /**
     * @param SwiftGiftInterface $gift
     * @throws CouldNotSaveException
     */
    public function save(SwiftGiftInterface $gift)
    {
        try {
            $this->resourceModel->save($gift);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(
                __('Could not save the gift: %1', $e->getMessage()),
                $e
            );
        }
    }

    /**
     * @param $id
     * @return SwiftGift
     * @throws NoSuchEntityException
     */
    public function getById($id)
    {
        /** @var \GiftMagic\GetGiftMagic\Model\SwiftGift $model */
        $model = $this->swiftGiftFactory->create();
        $model->load($id);
        if (!$model->getId()) {
            throw new NoSuchEntityException(__('Gift with id "%1" does not exist.', $id));
        }

        return $model;
    }

    public function delete(SwiftGiftInterface $gift)
    {
        try {
            $this->resourceModel->delete($gift);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }

        return true;
    }

    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}
