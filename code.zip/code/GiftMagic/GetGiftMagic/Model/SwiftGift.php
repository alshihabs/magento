<?php

namespace GiftMagic\GetGiftMagic\Model;

use Magento\Framework\DataObject\IdentityInterface;
use GiftMagic\GetGiftMagic\Api\Data\SwiftGiftInterface;
use Magento\Framework\Model\AbstractModel;

class SwiftGift extends AbstractModel implements IdentityInterface, SwiftGiftInterface
{
    const CACHE_TAG = 'swift_gift';


    protected function _construct()
    {
        $this->_init('GiftMagic\GetGiftMagic\Model\ResourceModel\SwiftGift');
    }

    /**
     * @return array|string[]
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return parent::getData(self::ID);
    }

    /**
     * @return mixed
     */
    public function getItems()
    {
        return parent::getData(self::ITEMS);
    }

    /**
     * @return mixed
     */
    public function getCreatedAt()
    {
        return parent::getData(self::CREATED_AT);
    }

    /**
     * @return mixed
     */
    public function getUpdatedAt()
    {
        return parent::getData(self::UPDATED_AT);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * @param $items
     * @return mixed
     */
    public function setItems($items)
    {
        return $this->setData(self::ITEMS, $items);
    }
}
