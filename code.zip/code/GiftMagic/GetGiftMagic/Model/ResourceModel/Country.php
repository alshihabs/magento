<?php

namespace GiftMagic\GetGiftMagic\Model\ResourceModel;

use Magento\Directory\Model\ResourceModel\Country as ParentCountry;

class Country extends ParentCountry
{
    public function getCodeByName($name)
    {
        $select = $this->getConnection()->select()
            ->from('msp_tfa_country_codes', 'code')
            ->where('name = ?', $name);

        return $this->getConnection()->fetchOne($select);
    }
}
