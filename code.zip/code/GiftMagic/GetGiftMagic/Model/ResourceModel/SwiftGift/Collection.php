<?php

namespace GiftMagic\GetGiftMagic\Model\ResourceModel\SwiftGift;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init('GiftMagic\GetGiftMagic\Model\SwiftGift', 'GiftMagic\GetGiftMagic\Model\ResourceModel\SwiftGift');
    }
}
