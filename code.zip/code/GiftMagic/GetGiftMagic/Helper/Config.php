<?php

namespace GiftMagic\GetGiftMagic\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class Config
{

    const GIFTMAGIC_DEFAULT_ACTIVE = 'giftmagic/default/active';
    const GIFTMAGIC_LICENSE_ACTIVE = 'giftmagic/license/active';
    const GIFTMAGIC_DEFAULT_URL = 'giftmagic/default/url';
    const GIFTMAGIC_DEFAULT_INTEGRATION_ID = 'giftmagic/default/integration';

    public function __construct(
        ScopeConfigInterface $scopeConfig
    )
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @return mixed
     */
    public function isActive()
    {
        return (bool)$this->scopeConfig->getValue(self::GIFTMAGIC_DEFAULT_ACTIVE, ScopeInterface::SCOPE_STORE) &&
            (bool)$this->scopeConfig->getValue(self::GIFTMAGIC_LICENSE_ACTIVE, ScopeInterface::SCOPE_STORE) &&
            (bool)$this->scopeConfig->getValue(self::GIFTMAGIC_DEFAULT_INTEGRATION_ID, ScopeInterface::SCOPE_STORE) &&
            (bool)$this->scopeConfig->getValue(self::GIFTMAGIC_DEFAULT_URL, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getGiftUrl()
    {
        return $this->scopeConfig->getValue(self::GIFTMAGIC_DEFAULT_URL, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getIntegrationId()
    {
        return $this->scopeConfig->getValue(self::GIFTMAGIC_DEFAULT_INTEGRATION_ID, ScopeInterface::SCOPE_STORE);
    }
}
