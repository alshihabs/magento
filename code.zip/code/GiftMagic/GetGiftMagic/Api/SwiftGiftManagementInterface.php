<?php

namespace GiftMagic\GetGiftMagic\Api;


interface SwiftGiftManagementInterface
{
    /**
     * @param string $url
     * @return mixed
     */
    public function setUrl($url);
}
