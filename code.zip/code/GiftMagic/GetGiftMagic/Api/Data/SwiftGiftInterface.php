<?php

namespace GiftMagic\GetGiftMagic\Api\Data;

interface SwiftGiftInterface
{
    const ID = 'id';
    const ITEMS = 'items';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    public function getId();

    public function getItems();

    public function getCreatedAt();

    public function getUpdatedAt();
}
