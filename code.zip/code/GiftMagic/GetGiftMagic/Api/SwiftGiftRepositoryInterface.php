<?php

namespace GiftMagic\GetGiftMagic\Api;

use GiftMagic\GetGiftMagic\Api\Data\SwiftGiftInterface;

interface SwiftGiftRepositoryInterface
{
    public function save(SwiftGiftInterface $gift);

    public function getById($id);

    public function delete(SwiftGiftInterface $gift);

    public function deleteById($id);
}
