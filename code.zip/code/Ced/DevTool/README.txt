Installation Steps for windows:
1. Download Package
2. Copy package files in MagentoRootDirectory/app/code
3. Open cmd
4. cd upto magento RootDirectory
5. run command "php bin/magento setup:upgrade"
6. run command "php bin/magento cache:flush"

Installation Steps for Linux
1. Download Package
2. Copy package files in MagentoRootDirectory/app/code
3. Open shell
4. cd upto magento RootDirectory
5. run command "bin/magento setup:upgrade"
6. run command "bin/magento cache:flush"

Steps For Enabling Developer Tool:
1. Open admin panel
2. Open STORES-> Configuration
3. Then Open Cedcommerce -> Developer Tool from left panel
4. Set yes in "Enable Developer Tool" field ( now developer tool will be showed)
5. if you want to show it for your ip only then set your ip in "Allowed IPs" field