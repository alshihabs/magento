var config = {
    map: {
        '*': {
            hello:           'Learning_Js/js/hello',
        }
    }
};
