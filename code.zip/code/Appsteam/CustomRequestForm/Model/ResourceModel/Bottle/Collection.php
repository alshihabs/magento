<?php
namespace Appsteam\CustomRequestForm\Model\ResourceModel\Bottle;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = 'appsteam_collection';
	protected $_eventObject = 'Bottle_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Appsteam\CustomRequestForm\Model\Bottle', 'Appsteam\CustomRequestForm\Model\ResourceModel\Bottle');
	}

}