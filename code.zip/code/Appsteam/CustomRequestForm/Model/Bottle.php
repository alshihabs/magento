<?php
namespace Appsteam\CustomRequestForm\Model;
class Bottle extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'appsteam';

	protected $_cacheTag = 'appsteam';

	protected $_eventPrefix = 'appsteam';

	protected function _construct()
	{
		$this->_init('Appsteam\CustomRequestForm\Model\ResourceModel\Bottle');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}