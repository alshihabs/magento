<?php

 \Magento\Framework\Component\ComponentRegistrar::register(

\Magento\Framework\Component\ComponentRegistrar::THEME,

'adminhtml/Bss/Backend',

__DIR__

);